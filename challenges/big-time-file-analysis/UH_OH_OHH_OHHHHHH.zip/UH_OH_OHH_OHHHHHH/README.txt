AAAAAAGGGGGGHHHHHHHHHHHH!!!!!!!!!!!!!!

We have another song due in TWENTY-FOUR HOURS, and the DOGS still haven't shown up! I can't find them anywhere!!!!!! If we don't get them in the studio ASAP, I WILL LOSE MY JOB.

YOU! You're smart, right? FIND ALL FOUR MEMBERS OF THIS STUPID BAND, and BRING. THEM. TO. ME. We need to record this song, and I can't make it happen, UNLESS THEY SHOW UP.

--

Oh, sorry for Gustavo's outburst, he's like that sometimes. Hi, I'm Kelly, and we need to get Big Time Rush here ASAP. Can you help us? 

The boys are kinda mischievous, and like to hide in...really random places, but I'm sure you'll be able to find them! Also, it's highly likely that once you find them, they won't go with you unless you answer some kind of question or riddle they have. They love their fans, and you need to prove you're the best of them!

By the way, those answers will probably come in handy for your special quest too, so hold onto them.

Now go, this song won't record itself!
